-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : lun. 11 déc. 2023 à 19:18
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `contracts`
--

CREATE TABLE `contracts` (
  `id` int(11) NOT NULL,
  `contract_date` date NOT NULL,
  `contract_copies` int(11) NOT NULL,
  `contract1_1` text DEFAULT NULL,
  `contract_date2` date DEFAULT NULL,
  `contract_sign` varchar(255) DEFAULT NULL,
  `contract_sign_me` varchar(255) DEFAULT NULL,
  `contract1_2` text DEFAULT NULL,
  `contract1_3` text DEFAULT NULL,
  `contract2_1` text DEFAULT NULL,
  `contract3_1_1` text DEFAULT NULL,
  `contract3_1_2` text DEFAULT NULL,
  `contract3_1_3` text DEFAULT NULL,
  `contract4_1_1` text DEFAULT NULL,
  `contract6_1` text DEFAULT NULL,
  `contract9_1` text DEFAULT NULL,
  `contract_12_1` text DEFAULT NULL,
  `some_location` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `contract_partners`
--

CREATE TABLE `contract_partners` (
  `id` int(11) NOT NULL,
  `contract_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `contract_partner_names`
--

CREATE TABLE `contract_partner_names` (
  `id` int(11) NOT NULL,
  `contract_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `username`) VALUES
(1, 'email@eail.com', '$2a$10$dJYkd54neeTETPQIC2r6iOtZ3WvdnIV4Czj09E2r2yMnLGVHDDtTW', 'test'),
(2, 'martial.laubier@orange.fr', '$2a$10$gp07SLl.gqNQQkjgjxOd0.BiDPaTcSOHWtBXJeDk9o0reUjaS3d7a', 'martial404'),
(3, 'm.laubier@eleve.leschartreux.net', '$2a$10$9MMaVFQyQNdZd5V5RlQzdOwMDY4luFTStbSLz1SCSuaWwm1vnwbU6', 'test'),
(4, 'aurel@gmail.com', '$2a$10$2JC5ZWcLDy8xAIGAuDLn6e66gb23jSfcB7L6T6Nfot2OGn2UXXuIS', 'aurel'),
(5, 'test@gmail.com', '$2a$10$QsoQ6gQ5EXyoH5usX5j4TenKxNVo7WaJ.5eaY8wPSjAENXAn7vvVi', 'TEST');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `contract_partners`
--
ALTER TABLE `contract_partners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_id` (`contract_id`);

--
-- Index pour la table `contract_partner_names`
--
ALTER TABLE `contract_partner_names`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_id` (`contract_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `contracts`
--
ALTER TABLE `contracts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `contract_partners`
--
ALTER TABLE `contract_partners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `contract_partner_names`
--
ALTER TABLE `contract_partner_names`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `contract_partners`
--
ALTER TABLE `contract_partners`
  ADD CONSTRAINT `contract_partners_ibfk_1` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`);

--
-- Contraintes pour la table `contract_partner_names`
--
ALTER TABLE `contract_partner_names`
  ADD CONSTRAINT `contract_partner_names_ibfk_1` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
